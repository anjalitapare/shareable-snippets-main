import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-test-now-ms, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function generateId(length = 10): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  const randomValues = new Uint8Array(length);
  crypto.getRandomValues(randomValues);
  for (let i = 0; i < length; i++) {
    result += chars[randomValues[i] % chars.length];
  }
  return result;
}

function getCurrentTime(headers: Headers): number {
  const testMode = Deno.env.get("TEST_MODE") === "1";
  if (testMode) {
    const testNowMs = headers.get("x-test-now-ms");
    if (testNowMs) {
      const parsed = parseInt(testNowMs, 10);
      if (!isNaN(parsed)) {
        return parsed;
      }
    }
  }
  return Date.now();
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const url = new URL(req.url);
  const pathParts = url.pathname.split("/").filter(Boolean);
  const pasteId = pathParts.length > 1 ? pathParts[pathParts.length - 1] : null;

  // GET /pastes/:id - Fetch a paste
  if (req.method === "GET" && pasteId && pasteId !== "pastes") {
    try {
      const nowMs = getCurrentTime(req.headers);
      console.log(`Fetching paste: ${pasteId}, nowMs: ${nowMs}`);

      const { data: paste, error } = await supabase
        .from("pastes")
        .select("*")
        .eq("id", pasteId)
        .maybeSingle();

      if (error) {
        console.error("Database error:", error);
        return new Response(
          JSON.stringify({ error: "Internal server error" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      if (!paste) {
        return new Response(
          JSON.stringify({ error: "Paste not found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Check if expired by TTL
      if (paste.expires_at) {
        const expiresAtMs = new Date(paste.expires_at).getTime();
        if (nowMs >= expiresAtMs) {
          await supabase.from("pastes").delete().eq("id", pasteId);
          return new Response(
            JSON.stringify({ error: "Paste has expired" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }

      // Check if view limit already exceeded
      if (paste.max_views !== null && paste.view_count >= paste.max_views) {
        await supabase.from("pastes").delete().eq("id", pasteId);
        return new Response(
          JSON.stringify({ error: "View limit exceeded" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Increment view count
      const newViewCount = paste.view_count + 1;
      await supabase
        .from("pastes")
        .update({ view_count: newViewCount })
        .eq("id", pasteId);

      // Calculate remaining views
      let remainingViews: number | null = null;
      if (paste.max_views !== null) {
        remainingViews = Math.max(0, paste.max_views - newViewCount);
        if (remainingViews <= 0) {
          await supabase.from("pastes").delete().eq("id", pasteId);
        }
      }

      return new Response(
        JSON.stringify({
          content: paste.content,
          remaining_views: remainingViews,
          expires_at: paste.expires_at,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (error) {
      console.error("Error fetching paste:", error);
      return new Response(
        JSON.stringify({ error: "Internal server error" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  }

  // POST /pastes - Create a paste
  if (req.method === "POST") {
    try {
      let body;
      try {
        body = await req.json();
      } catch {
        return new Response(
          JSON.stringify({ error: "Invalid JSON body" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Validate content
      if (!body.content || typeof body.content !== "string") {
        return new Response(
          JSON.stringify({ error: "content is required and must be a string" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      if (body.content.trim() === "") {
        return new Response(
          JSON.stringify({ error: "content must be a non-empty string" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Validate ttl_seconds
      let expiresAt: string | null = null;
      if (body.ttl_seconds !== undefined && body.ttl_seconds !== null) {
        if (typeof body.ttl_seconds !== "number" || !Number.isInteger(body.ttl_seconds)) {
          return new Response(
            JSON.stringify({ error: "ttl_seconds must be an integer" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        if (body.ttl_seconds < 1) {
          return new Response(
            JSON.stringify({ error: "ttl_seconds must be >= 1" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        const nowMs = getCurrentTime(req.headers);
        expiresAt = new Date(nowMs + body.ttl_seconds * 1000).toISOString();
      }

      // Validate max_views
      let maxViews: number | null = null;
      if (body.max_views !== undefined && body.max_views !== null) {
        if (typeof body.max_views !== "number" || !Number.isInteger(body.max_views)) {
          return new Response(
            JSON.stringify({ error: "max_views must be an integer" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        if (body.max_views < 1) {
          return new Response(
            JSON.stringify({ error: "max_views must be >= 1" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        maxViews = body.max_views;
      }

      const id = generateId(10);
      console.log(`Creating paste: ${id}`);

      const { error } = await supabase.from("pastes").insert({
        id,
        content: body.content,
        max_views: maxViews,
        expires_at: expiresAt,
      });

      if (error) {
        console.error("Error creating paste:", error);
        return new Response(
          JSON.stringify({ error: "Failed to create paste" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Build response URL
      const protocol = req.headers.get("x-forwarded-proto") || "https";
      const host = req.headers.get("host") || "localhost:3000";
      const pasteUrl = `${protocol}://${host}/p/${id}`;

      return new Response(
        JSON.stringify({ id, url: pasteUrl }),
        { status: 201, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (error) {
      console.error("Error creating paste:", error);
      return new Response(
        JSON.stringify({ error: "Internal server error" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  }

  return new Response(
    JSON.stringify({ error: "Method not allowed" }),
    { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
});
