-- Create pastes table
CREATE TABLE public.pastes (
  id TEXT PRIMARY KEY,
  content TEXT NOT NULL,
  max_views INTEGER DEFAULT NULL,
  view_count INTEGER NOT NULL DEFAULT 0,
  expires_at TIMESTAMPTZ DEFAULT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS but allow public access (pastes are public by design)
ALTER TABLE public.pastes ENABLE ROW LEVEL SECURITY;

-- Anyone can read pastes (needed to view shared links)
CREATE POLICY "Anyone can read pastes"
  ON public.pastes FOR SELECT
  USING (true);

-- Anyone can create pastes (no auth required)
CREATE POLICY "Anyone can create pastes"
  ON public.pastes FOR INSERT
  WITH CHECK (true);

-- Anyone can update pastes (for view count increment)
CREATE POLICY "Anyone can update pastes"
  ON public.pastes FOR UPDATE
  USING (true);

-- Anyone can delete pastes (for cleanup of expired)
CREATE POLICY "Anyone can delete pastes"
  ON public.pastes FOR DELETE
  USING (true);