import { supabase } from "@/integrations/supabase/client";

export interface CreatePasteInput {
  content: string;
  ttl_seconds?: number;
  max_views?: number;
}

export interface CreatePasteResponse {
  id: string;
  url: string;
}

export interface FetchPasteResponse {
  content: string;
  remaining_views: number | null;
  expires_at: string | null;
}

export async function createPaste(input: CreatePasteInput): Promise<CreatePasteResponse> {
  const { data, error } = await supabase.functions.invoke("pastes", {
    method: "POST",
    body: input,
  });

  if (error) {
    throw new Error(error.message || "Failed to create paste");
  }

  if (data?.error) {
    throw new Error(data.error);
  }

  return data;
}

export async function fetchPaste(id: string): Promise<FetchPasteResponse> {
  const { data, error } = await supabase.functions.invoke(`pastes/${id}`, {
    method: "GET",
  });

  if (error) {
    throw new Error(error.message || "Failed to fetch paste");
  }

  if (data?.error) {
    throw new Error(data.error);
  }

  return data;
}

export async function healthCheck(): Promise<boolean> {
  try {
    const { data, error } = await supabase.functions.invoke("healthz", {
      method: "GET",
    });

    if (error) return false;
    return data?.ok === true;
  } catch {
    return false;
  }
}
