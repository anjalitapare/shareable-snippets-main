import Header from "@/components/Header";
import CreatePasteForm from "@/components/CreatePasteForm";

const Index = () => {
  return (
    <div className="min-h-screen bg-background gradient-surface">
      <Header />
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto space-y-8">
          <div className="text-center space-y-4 animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold gradient-text">
              Share Text Securely
            </h1>
            <p className="text-lg text-muted-foreground max-w-lg mx-auto">
              Create ephemeral pastes with optional expiration and view limits. 
              Your content, your control.
            </p>
          </div>
          <CreatePasteForm />
        </div>
      </main>
    </div>
  );
};

export default Index;
