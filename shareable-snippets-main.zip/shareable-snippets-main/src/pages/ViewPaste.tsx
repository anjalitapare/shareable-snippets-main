import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import Header from "@/components/Header";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { fetchPaste, FetchPasteResponse } from "@/lib/api";
import { Clock, Eye, FileText, AlertCircle, Loader2, Copy, Check, ArrowLeft } from "lucide-react";

function escapeHtml(text: string): string {
  const htmlEscapes: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  };
  return text.replace(/[&<>"']/g, (char) => htmlEscapes[char] || char);
}

export default function ViewPaste() {
  const { id } = useParams<{ id: string }>();
  const [paste, setPaste] = useState<FetchPasteResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    async function loadPaste() {
      if (!id) {
        setError("Invalid paste ID");
        setLoading(false);
        return;
      }

      try {
        const data = await fetchPaste(id);
        setPaste(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load paste");
      } finally {
        setLoading(false);
      }
    }

    loadPaste();
  }, [id]);

  const handleCopy = async () => {
    if (paste?.content) {
      await navigator.clipboard.writeText(paste.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background gradient-surface">
        <Header />
        <main className="container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto flex items-center justify-center py-24">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </main>
      </div>
    );
  }

  if (error || !paste) {
    return (
      <div className="min-h-screen bg-background gradient-surface">
        <Header />
        <main className="container mx-auto px-4 py-12">
          <div className="max-w-md mx-auto text-center space-y-6 animate-fade-in">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-destructive/10 mb-4">
              <AlertCircle className="h-10 w-10 text-destructive" />
            </div>
            <h1 className="text-3xl font-bold">Paste Not Found</h1>
            <p className="text-muted-foreground">
              {error || "This paste doesn't exist or is no longer available."}
            </p>
            <Button asChild className="gradient-bg">
              <Link to="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Create New Paste
              </Link>
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background gradient-surface">
      <Header />
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-6 animate-slide-up">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <Button asChild variant="ghost" size="sm">
              <Link to="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                New Paste
              </Link>
            </Button>

            <div className="flex flex-wrap items-center gap-3">
              {paste.remaining_views !== null && (
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent/10 text-accent text-sm">
                  <Eye className="h-4 w-4" />
                  {paste.remaining_views} view{paste.remaining_views !== 1 ? "s" : ""} remaining
                </div>
              )}
              {paste.expires_at && (
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm">
                  <Clock className="h-4 w-4" />
                  Expires: {new Date(paste.expires_at).toLocaleString()}
                </div>
              )}
            </div>
          </div>

          <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-4 border-b border-border/50">
              <div className="flex items-center gap-2 text-muted-foreground">
                <FileText className="h-5 w-5" />
                <span className="font-medium">Paste Content</span>
              </div>
              <Button size="sm" variant="ghost" onClick={handleCopy}>
                {copied ? (
                  <>
                    <Check className="mr-2 h-4 w-4 text-green-500" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="mr-2 h-4 w-4" />
                    Copy
                  </>
                )}
              </Button>
            </CardHeader>
            <CardContent className="p-0">
              <pre className="p-6 font-mono text-sm text-foreground whitespace-pre-wrap break-words overflow-x-auto">
                {escapeHtml(paste.content)}
              </pre>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
