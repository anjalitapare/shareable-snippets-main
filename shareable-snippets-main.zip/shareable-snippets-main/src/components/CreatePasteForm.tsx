import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { createPaste } from "@/lib/api";
import { Clipboard, Clock, Eye, Loader2, Link2, Copy, Check } from "lucide-react";

export default function CreatePasteForm() {
  const [content, setContent] = useState("");
  const [ttlSeconds, setTtlSeconds] = useState("");
  const [maxViews, setMaxViews] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ id: string; url: string } | null>(null);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setResult(null);

    try {
      const body: { content: string; ttl_seconds?: number; max_views?: number } = { content };

      if (ttlSeconds.trim()) {
        const ttl = parseInt(ttlSeconds, 10);
        if (isNaN(ttl) || ttl < 1) {
          throw new Error("TTL must be a positive integer");
        }
        body.ttl_seconds = ttl;
      }

      if (maxViews.trim()) {
        const views = parseInt(maxViews, 10);
        if (isNaN(views) || views < 1) {
          throw new Error("Max views must be a positive integer");
        }
        body.max_views = views;
      }

      const data = await createPaste(body);
      setResult(data);
      toast({
        title: "Paste created!",
        description: "Your paste is ready to share.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create paste",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    if (result?.url) {
      await navigator.clipboard.writeText(result.url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleViewPaste = () => {
    if (result?.id) {
      navigate(`/p/${result.id}`);
    }
  };

  const handleNewPaste = () => {
    setContent("");
    setTtlSeconds("");
    setMaxViews("");
    setResult(null);
  };

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm animate-slide-up">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl flex items-center gap-2">
          <Clipboard className="h-6 w-6 text-primary" />
          New Paste
        </CardTitle>
        <CardDescription>
          Create a secure, shareable text snippet
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!result ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="content" className="text-foreground">
                Content <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="content"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Paste your text here..."
                className="min-h-[200px] font-mono text-sm bg-background/50 border-border/50 focus:border-primary/50 transition-colors resize-y"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ttl" className="text-foreground flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  Expires after (seconds)
                </Label>
                <Input
                  id="ttl"
                  type="number"
                  min="1"
                  value={ttlSeconds}
                  onChange={(e) => setTtlSeconds(e.target.value)}
                  placeholder="Optional"
                  className="bg-background/50 border-border/50 focus:border-primary/50"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="maxViews" className="text-foreground flex items-center gap-2">
                  <Eye className="h-4 w-4 text-muted-foreground" />
                  Max views
                </Label>
                <Input
                  id="maxViews"
                  type="number"
                  min="1"
                  value={maxViews}
                  onChange={(e) => setMaxViews(e.target.value)}
                  placeholder="Optional"
                  className="bg-background/50 border-border/50 focus:border-primary/50"
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading || !content.trim()}
              className="w-full gradient-bg glow-primary hover:opacity-90 transition-opacity"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : (
                "Create Paste"
              )}
            </Button>
          </form>
        ) : (
          <div className="space-y-6 animate-fade-in">
            <div className="text-center space-y-2">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full gradient-bg mb-4">
                <Check className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold">Paste Created!</h3>
              <p className="text-muted-foreground">Your paste is ready to share</p>
            </div>

            <div className="flex items-center gap-2 p-3 bg-background/50 rounded-lg border border-border/50">
              <Link2 className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <code className="font-mono text-sm text-foreground flex-1 truncate">
                {result.url}
              </code>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleCopy}
                className="flex-shrink-0"
              >
                {copied ? (
                  <Check className="h-4 w-4 text-green-500" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </Button>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <Button onClick={handleViewPaste} className="flex-1 gradient-bg">
                View Paste
              </Button>
              <Button onClick={handleNewPaste} variant="outline" className="flex-1">
                Create Another
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
