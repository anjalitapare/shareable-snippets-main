import { Link } from "react-router-dom";
import { Clipboard } from "lucide-react";

export default function Header() {
  return (
    <header className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
          <div className="p-2 rounded-lg gradient-bg">
            <Clipboard className="h-5 w-5 text-white" />
          </div>
          <span className="text-xl font-bold gradient-text">Pastebin-Lite</span>
        </Link>
        <p className="text-sm text-muted-foreground hidden sm:block">
          Secure, ephemeral text sharing
        </p>
      </div>
    </header>
  );
}
